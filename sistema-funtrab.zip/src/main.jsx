import React from 'react';
import ReactDOM from 'react-dom/client';
import SistemaEncaminhamentos from './SistemaEncaminhamentos';

ReactDOM.createRoot(document.getElementById('root')).render(<SistemaEncaminhamentos />);